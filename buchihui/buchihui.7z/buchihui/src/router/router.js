
const list = [
  {
    path: '/',
    src: '/index'
  },
  {
    path: 'nav',
    src: 'nav'
  },
];
export default list;
