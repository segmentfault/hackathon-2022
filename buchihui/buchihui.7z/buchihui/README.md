
## 不吃灰 —— 收藏夹管理项目

### readme

```
由 create-react-app 创建

安装
npm install 

运行即可
npm start

```


### 其他

aGPL v3
