# -*- coding:utf-8 -*-
ss = '\n      1922   \n'
print(ss.strip('\n').strip(' '))
