# -*- coding: utf-8 -*-
"""
Created on Thu Jun 23 17:46:20 2022

@author: 86156
"""

for i in range(1, 10):
  for j in range(1, i+1):
    print(i, "x", j, "=", i * j, end=' ')
    print("\n")