# -*- coding: utf-8 -*-
"""将一个列表的数据复制到另一个列表中。
Created on Mon Aug  8 09:04:11 2022

@author: 86156
"""
a = [1, 2, 3]
b = a[:]
print (b)
