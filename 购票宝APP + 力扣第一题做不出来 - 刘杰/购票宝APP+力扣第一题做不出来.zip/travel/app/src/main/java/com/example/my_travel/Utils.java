package com.example.my_travel;

/**
 * 文件名：Utils
 * 作  者： 唐辉
 * 日  期：6/9/22 10:48 AM
 * 描述：TOOD
 */
public class Utils {
    public static String NAME = "";
}
