package com.example.my_travel.utils;

import android.view.View;

public interface MyItem {
    void OnClick(View view,int position);
}
