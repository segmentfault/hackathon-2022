package io.hikarilan.classschedule.data

data class TransformData(val part1: List<ClassEntity>, val part2: List<PreferenceEntity>)