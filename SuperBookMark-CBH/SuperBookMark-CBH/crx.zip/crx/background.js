
// chrome.browserAction.onClicked.addListener(function () {
//   chrome.management.getSelf(function (res) {
//     chrome.tabs.create({ url: 'chrome-extension://' + res.id + '/index.html' });
//   });
// });
